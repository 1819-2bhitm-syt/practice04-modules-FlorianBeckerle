const setCountdown = require("./countdown");

setCountdown(10);